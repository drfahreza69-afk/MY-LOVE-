# 🚀 MY PORTOFOLIO BY REXZA — DAFFA RIFKI FAHREZA HQ

> **Personal Command Center & Interactive Portfolio**  
> Daffa Rifki Fahreza — Document Control (DC) Specialist & Digital Command Center.

![HTML5](https://img.shields.io/badge/HTML5-E34F26?style=for-the-badge&logo=html5&logoColor=white)
![CSS3](https://img.shields.io/badge/CSS3-1572B6?style=for-the-badge&logo=css3&logoColor=white)
![JavaScript](https://img.shields.io/badge/JavaScript-F7DF1E?style=for-the-badge&logo=javascript&logoColor=black)
![Web Audio API](https://img.shields.io/badge/Web%20Audio-Synth-00F2FE?style=for-the-badge)
![GitHub Pages](https://img.shields.io/badge/GitHub%20Pages-Live-success?style=for-the-badge&logo=github)

---

## ✨ Fitur Utama (Key Features)

### 1. 🛡️ Cybernetic / Sci-Fi Login Gate
- **Biometric Arc Reactor**: Gyroscope 3D 3-cincin konsentris berputar dinamis dengan satelit orbiter dan laser pemindai biometrik real-time.
- **Cyber Telemetry Top HUD**: Indikator node aktif (`BEKASI-HQ // JKT SECTOR`) dan jam militer yang terus diperbarui setiap detik.
- **Sensor Telemetry Tiles**: Memantau status *Firewall (AES-512)*, *Integritas (100% OK)*, dan *Clearance (ALPHA-01)*.
- **Autentikasi Aman**: 1 form input kata sandi tanpa membocorkan kata sandi di layar.
- **Mode Tamu (Guest Preview)**: Tombol satu klik bagi pengunjung atau rekruter untuk menjelajahi portofolio tanpa hak admin.
- **Sintesis Audio Web Audio API**: Efek suara kemenangan cyber saat login berhasil dan peringatan saat sandi salah.

### 2. 📊 Statistik & Analitik Habit Tracker
- **7-Day Dynamic Bar Chart**: Diagram interaktif persentase penyelesaian habit harian dengan efek gradasi ultra modern.
- **Interactive Tooltip**: Sentuh/klik diagram bar untuk melihat persentase keberhasilan harian dan jumlah target terpenuhi.
- **KPI Metrics Card**: Rata-rata konsistensi, streak produktivitas, dan waktu produktif harian.

### 3. 🕌 Jadwal Sholat Otomatis & Adzan Suara
- **Deteksi GPS Lokasi**: Menghitung waktu sholat presisi berdasarkan koordinat lintang & bujur pengguna.
- **Penyorot Waktu Sholat Berikutnya**: Kartu jadwal adzan yang akan datang menyala (*glowing pulse*) otomatis.
- **Pemutar Suara Adzan**: Integrasi audio adzan beresolusi tinggi dengan opsi putar otomatis atau manual.

### 4. 📝 Multi-Notes Hub (Sistem Catatan Multi-Slot)
- **Penyimpanan Lokal Persisten**: Catatan tersimpan aman di browser (*LocalStorage*).
- **Kategori Fleksibel**: Tugas Proyek, Ide Cepat, Pengingat DC, Catatan Ibadah, dan Pribadi.
- **Manajemen Lengkap**: Buat baru, edit, simpan, dan hapus catatan dengan cepat.

### 5. 🎨 Dual Theme: Sky Clay & Pixar 3D
- **Sky Clay**: Estetika Claymorphism lembut bernuansa biru langit cerah dengan *liquid frosted glass*.
- **Pixar 3D**: Estetika Dark Obsidian dengan neon glow liquid, partikel aurora cair, dan sentuhan visual futuristik.

### 6. 🎬 Sinematik Galeri Video & Foto Penyemangat
- **Video Hero 60fps**: Pemutar video sinematik di beranda yang responsif dan fleksibel.
- **Galeri Video Interaktif**: Koleksi klip aksi dan sinematik dengan kemampuan upload dan ganti video kustom.
- **Foto Penyemangat Lightbox**: Tampilan foto potret dengan rasio yang disesuaikan agar wajah terlihat proporsional, dilengkapi fitur *zoom preview*.

---

## 📁 Struktur Berkas (File Structure)

```text
├── index.html                                   # Aplikasi portofolio utama (Single-Page App)
├── adzan_sound.mp3                              # Audio adzan lokal
├── motivation_couple.jpg                        # Foto penyemangat profil
├── ssstik.io_@luxueqi0_1792063154898.mp4         # Video sinematik beranda
├── WhatsApp Video 2026-10-16 at 01.00.41.mp4     # Video klip galeri 01
├── WhatsApp Video 2026-10-16 at 01.01.09.mp4     # Video klip galeri 02
├── WhatsApp Video 2026-10-16 at 01.25.24.mp4     # Video klip galeri 03
├── WhatsApp Video 2026-10-16 at 01.25.32.mp4     # Video klip galeri 04
├── README.md                                    # Dokumentasi proyek
└── .gitignore                                   # Konfigurasi pengabaian berkas Git
```

---

## 🌐 Cara Mengunggah & Mengaktifkan di GitHub Pages (Deploy)

Portofolio ini dirancang murni tanpa server (*zero backend dependency*), sehingga dapat langsung di-hosting secara gratis menggunakan **GitHub Pages**:

1. **Buat Repository Baru di GitHub**:
   - Masuk ke [GitHub.com](https://github.com).
   - Klik tombol **New** (Buat Repository).
   - Beri nama repository, contoh: `portofolio-daffa` atau `my-portfolio`.
   - Pilih opsi **Public**.
   - Klik **Create repository**.

2. **Unggah Semua Berkas**:
   - Di halaman repository baru Anda, klik tautan **uploading an existing file**.
   - Tarik (drag & drop) seluruh berkas yang ada di folder ini:
     - `index.html`
     - `adzan_sound.mp3`
     - `motivation_couple.jpg`
     - Semua berkas `.mp4`
     - `README.md`
   - Klik **Commit changes**.

3. **Aktifkan GitHub Pages**:
   - Masuk ke tab **Settings** di menu atas repository Anda.
   - Pada sidebar kiri, pilih menu **Pages**.
   - Pada bagian **Build and deployment** > **Source**, pilih opsi **Deploy from a branch**.
   - Pada menu dropdown Branch, pilih **main** (atau **master**), folder pilih `/ (root)`, lalu klik **Save**.
   - Tunggu sekitar 1–2 menit, GitHub akan memberikan link website aktif Anda:  
     `https://<username-kamu>.github.io/<nama-repo>/`

---

## 🔒 Akses Admin Command Center
- Halaman portal login dilengkapi pengaman akses administratif.
- Sandi bawaan admin: `35431399` *(dapat diubah kapan saja di menu Admin Panel)*.
- Pengunjung umum dapat menekan tombol **Jelajahi Sebagai Tamu (Guest Preview)** untuk langsung melihat seluruh isi portofolio.

---

## 👨‍💻 Profil Pemilik
- **Nama**: Daffa Rifki Fahreza (Rexza)
- **Keahlian**: Document Control (DC) & Web Command Center Architecture
- **Lokasi**: Bekasi / Jakarta Sector, Indonesia
- **Tahun**: 2026
